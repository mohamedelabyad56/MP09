package elabyad.mohamed.dam.mp09.uf01.pr2.app;

import elabyad.mohamed.dam.mp09.uf01.pr2.seguretat.controller.VisitaMedicaController;

public class Main {

    public static void main(String[] args) {
       
        VisitaMedicaController controller = new VisitaMedicaController();
        
        controller.inici();
    }
}
